ALBERTO ROMO MARTÍN - BOOSTWARS README

Anotaciones sobre los documentos de entrega de este Zip. En el zip se incluye:

-Pdf con la memoria del proyecto. Al final de la sección de bibliografía se adjunta el enlace al repositorio de github conm todo el código del juego.
-.apk para instalar Boostwars en dispositivo movil Android, sistema operativo usado como objetivo del proyecto. Si desea el instalador para dispositivo móvil IOS mándememe mensaje al correo alberto.romartin@alumnos.upm.es.
Debido al tamaño de la entrega disponible en moodle, se adjunta a continuación un enlace a un repositorio de Github 
	https://github.com/albertoromartin/TFM_Boostwars_RomoMartin

donde se han subido los siguientes componentes
	-Arhivo comprimido con la carpeta BoostwarsBuildPC se incluye el archivo BoostWars.exe para poder ejecutar el juego en Windows. Es necesario el directorio entero para ejecutar el .exe.
	-Carpeta BoostWars con los directorios necesarios para abrir el proyecto en Unity, entorno que se ha usado para el desarrollo (versión 2021.3.18f1).
		*La escena principal es la situada en Assets/Scenes/MainTile.unity.
		*En el directorio Assets/Scripts están ubicados todos los scripts usados por la aplicación. Todos ellos están escritos en lenguaje C#. Se recomienda el uso de Visual Studio para abrirlos.
		*Para abrir el proyecto en UnityHub, seleccione la carpera llamada 'BoostwarsTFMUnity' y seleccione abrir en esa instancia. Despues de unos minutos, se abrirá el proyecto en el entorno unity.

El rendimiento del juego es ligeramente mejor en Windows.
Para cualquier incidencia, contacet al correo electrónico alberto.romartin@alumnos.upm.es

Alberto Romo